<?php

// $shopifyApiKey = "c3060c971def7799e29cb7e43c6ec174";
// $shopifyPassword = "89615867e56809d2e8fcaf01a7916902";
// $shopifyToken = "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";
// $shopifyStoreUrl = "https://anytimetoolandauto.com";
// $jsonFileUrl = "first_500.json";

$jsonData = file_get_contents($jsonFileUrl);
$products = json_decode($jsonData, true);


$processedProducts = 0;

foreach ($products as $product) {
    try {
      
        $processedProducts++;

        if ($processedProducts <= 55) {
            continue;
        }

        $title = $product['Title'];
        $description = $product['long_description'];
        $vendor = $product['Manufacturer'];
        $tags = $product['SUBCATEGORY'];
        $image = $product['IMAGE'];
        $price = $product['LIST'];
        $productType = $product['CATEGORY'];

        $productData = array(
            'product' => array(
                'title' => $title,
                'body_html' => $description,
                'vendor' => $vendor,
                'tags' => $tags,
                'images' => array(array('src' => $image)),
                'variants' => array(
                    array(
                        'price' => $price,
                    ),
                ),
                'product_type' => $productType,
                'status' => 'active',
            )
        );

        $productDataJson = json_encode($productData);

        $apiEndpoint = 'https://c3060c971def7799e29cb7e43c6ec174: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@5f9e44.myshopify.com/admin/api/2023-10/products.json';

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $apiEndpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $productDataJson,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'X-Shopify-Access-Token: ' . $shopifyToken,
            ),
        ));

        $response = curl_exec($curl);

        if (curl_errno($curl)) {
            throw new Exception('Curl error: ' . curl_error($curl));
        }

        curl_close($curl);

        echo $response;
        echo "Product with ID added: " . json_decode($response, true)['product']['id'] . "\n";
    } catch (Exception $e) {
        echo 'Exception: ' . $e->getMessage() . "\n";
    }
}
?>
<!-- https://c3060c971def7799e29cb7e43c6ec174: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@5f9e44.myshopify.com/admin/api/2023-10/products.json -->




<!-- https://anytimetoolandauto.com/admin/api/2023-10/products.json -->